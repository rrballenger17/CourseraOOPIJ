package graph;

// Abstract class that is implemented by 
// GraphEasyProblem and GraphHardProblem 
// Also used to pass to the graph loader.
public abstract class Graph {

	public abstract void addVertex(int input);
	public abstract void addEdge(int x, int y);

}
