package graph;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.ArrayList;
import java.util.Map;
import java.util.Stack;

// Solution for the easy problem
// It runs a single generation of 
// changes. There are 2 possible 
// seletions for each node (0 or 1). 
// The hard problem solution can handle
// 3 or more possible selections.

public class GraphEasyProblem {

	// stores the nodes and connections
	private HashMap<Integer, Node> graph = new HashMap<Integer, Node>();
	
	// likability factor of each selection
	// for the easy problem it is .75 for each selection
	private Map<Integer, Double> benefitFactors = getBenefitFactors();
	
	private Random myRand = new Random();
	
	// Sets each selection to have a benefit factor
	// of .75. Returns a map containing the benefits
	private Map<Integer, Double> getBenefitFactors() {
		
		Map<Integer, Double> factors = new HashMap<Integer, Double>();
		
		factors.put(0, .75);
		factors.put(1, .75);
		
		return factors;
	}
	
	// Adds a vertex to the graph
	public void addVertex(int num) {
		// TODO Auto-generated method stub
		if(!graph.keySet().contains(num)){
			graph.put(num, new Node());
			graph.get(num).setId(num);;
		}
	}
	
	// Adds an edge to the internally stored graph
	public void addEdge(int from, int to) {
		// TODO Auto-generated method stub
		Node theNode = graph.get(from);
		HashSet<Integer> conns = theNode.getConnections();
		conns.add(to);
		theNode.setConnections(conns);
	}
	
	// Assign each nodes current selection (0 or 1)
	public void randomlyAssignSelection() {
		Random rand = new Random();
		for(int id: graph.keySet()) {
			Node node = graph.get(id);
			node.setSelection(rand.nextInt(2));
		}
	}
	
	// Print the state of all the nodes (id and selection)
	public void printState() {
		for(int id: graph.keySet()) {
			Node node = graph.get(id);
			System.out.println("node: " + node.getId() + " selection: " + node.getSelection());
		}
	}

	// Count and print the number of nodes that
	// currently prefer each selection option (0 or 1)
	public void printSelectionCounts() {
		
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		
		for(int id: graph.keySet()) {
			Node node = graph.get(id);
			if(map.containsKey(node.getSelection())) {
				map.put(node.getSelection(), map.get(node.getSelection()) + 1);
			}else {
				map.put(node.getSelection(), 1);
			}
		}
		
		for(int selection: map.keySet()) {
			System.out.println("Selection: " + selection + " Count: " + map.get(selection));
		}	
	}
	
	//Run a single generation. For each node, count its 
	// neighbors current selection. Multiply the neighbor
	// counts by the likability factor and determine what
	// the nodes selection will be in the future. 
	public void runSingleGeneration() {
		
		// next gen selections
		Map<Integer, Integer> newSelections = new HashMap<Integer, Integer>();
		
		// for each node, count neighbors selections.
		// Then determine what the current node will select
		// next and save it in the newSelections map.
		for(int id: graph.keySet()) {
			
			Node n = graph.get(id);
			
			// neighbors selections and counts
			Map<Integer, Integer> neighsChoices = new HashMap<Integer, Integer>();
			
			// count each selection from each neighbor
			for(int neigh: n.getConnections()) {
				
				int nSelection = graph.get(neigh).getSelection();
				
				if(neighsChoices.containsKey(nSelection)) {
					int newCount = neighsChoices.get(nSelection) + 1;
					neighsChoices.put(nSelection, newCount);
				}else {
					neighsChoices.put(nSelection, 1);
				}
			}
			
			// determine next gen choice by maximum benefit
			int newPick = -1;
			double newPickBenefit = -1.0;
			
			// for each selection type of all the neighbors, 
			// determine its benefit which is the total neighbors
			// using the selection multiplied by the likability factor
			for(int option: neighsChoices.keySet()) {
				
				int optionCount = neighsChoices.get(option);
				
				//double benefitFactor = .5;//benefitFactors.get(option);
				
				double optionBenefit = (optionCount + 0.0) * .75; //* benefitFactor; 
				
				if(optionBenefit > newPickBenefit) {
					
					newPickBenefit = optionBenefit;
					newPick = option;
				}else if(optionBenefit == newPickBenefit) {
					if(myRand.nextBoolean()) {
						newPickBenefit = optionBenefit;
						newPick = option;
					}
				}
			}
			
			// save next gen choice
			newSelections.put(id, newPick);
			
		}
		
		// update nodes with next gen choice
		for(int id: newSelections.keySet()) {
			graph.get(id).setSelection(newSelections.get(id));
		}		
	}


	/* (non-Javadoc)
	 * @see graph.Graph#exportGraph()
	 */
	//@Override
	public HashMap<Integer, Node> exportGraph() {
		// TODO Auto-generated method stub
		return graph;
	}
	
} 