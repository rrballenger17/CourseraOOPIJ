package graph;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.ArrayList;
import java.util.Map;
import java.util.Stack;

// Run multiple generations of the node cascade model. 
// Each node has a selection from 2 or more options and
// can change its selection depending on its neighbors choices. 
// The overall percentage change of each selection is measured. 
// Also a designated group of nodes is monitored and it's noted
// when they all have chosen a particular option. 
public class GraphHardProblem extends Graph{

	private HashMap<Integer, Node> graph = new HashMap<Integer, Node>();
	
	private Map<Integer, Double> benefitFactors = null;
	
	private Random myRand = new Random();
		
	private int optionCount;

	private List<Integer> nodeGroup = null;
	
	private int nodeGroupChoice = -1;
	
	private int randomSeed = -1;
	
	private boolean randomlyGenerateBenefitFactors = false;
	
	private double DEFAULT_BENEFIT = .75;
	
	private boolean printed = false;
	
	private String nodeGroupMessage = "";
	
	// seed the random generator (optional) 
	// for a repeatable state
	public void setRandomSeed(int seed) {
		randomSeed = seed;
		
		System.out.println("\nRandom seed set to: " + randomSeed + "\n");
		
		myRand = new Random(randomSeed);
	}
	
	// Manually set a benefit factor for a
	// specific option
	private void setBenefitFactor(int choice, double factor) {
		benefitFactors.put(choice, factor);
	}

	// Either generate random benefit factors for each 
	// option from 0.0 to 1.0 or use the default benefit
	// factor of .75 for all the options. 
	private void generateBenefitFactors() {
		
			benefitFactors = new HashMap<Integer, Double>();
			
			int count = 0;
			
			// assign random or the default benefit for each
			while(count < optionCount) {
				double benFactor = randomlyGenerateBenefitFactors ? 
						myRand.nextDouble() : DEFAULT_BENEFIT;
				benefitFactors.put(count, benFactor);
				count++;
			}
			
			// print the benefit factors to the terminal
			System.out.println("");
			System.out.println("Benefit Factors");
			for(int i=0; i<optionCount; i++) {
				
				System.out.println("Node: " + (i + 1) + ": " + benefitFactors.get(i));
			}
			System.out.println("");
			
	}
	
	// Monitor a specific group of nodes to determine
	// when they all chose, if ever, a specific option.
	// This function enables the user to specify which 
	// nodes
	public void specificNodes(List<Integer> nodes, int choice) {
		
		nodeGroup = nodes;
		
		nodeGroupChoice = choice;
		
		System.out.println("\nThe specific nodes are:");
		
		for(int c : nodeGroup) {
			System.out.println(c);
		}
		
		System.out.println("\nThe selection for the nodes is:");
		System.out.println(nodeGroupChoice);
	}
	

	// add a vertex
	public void addVertex(int num) {
		// TODO Auto-generated method stub
		if(!graph.keySet().contains(num)){
			graph.put(num, new Node());
			graph.get(num).setId(num);;
		}
	}
	
	// add an edge
	public void addEdge(int from, int to) {
		// TODO Auto-generated method stub
		Node theNode = graph.get(from);
		HashSet<Integer> conns = theNode.getConnections();
		conns.add(to);
		theNode.setConnections(conns);
	}

	// Each node needs a selection from 2 or more options. 
	// This function assigns a selection to each node.
	public void randomlyAssignSelection(int choiceCount) {
		
		optionCount = choiceCount;

		for(int id: graph.keySet()) {
			Node node = graph.get(id);
			node.setSelection(myRand.nextInt(optionCount));
		}
		
		generateBenefitFactors();
	}
	
	// print each node id and its corresponding selection
	public void printState() {
		for(int id: graph.keySet()) {
			Node node = graph.get(id);
			System.out.println("node: " + node.getId() + " selection: " + node.getSelection());
		}
	}

	// Count all the nodes that have selected each option. 
	// Put the counts in the hashmap and return it to the caller
	private Map<Integer, Integer> countNodesPerSelection(){
		
		Map<Integer, Integer> map = new HashMap<Integer, Integer>();
		
		for(int id: graph.keySet()) {
			Node node = graph.get(id);
			if(map.containsKey(node.getSelection())) {
				map.put(node.getSelection(), map.get(node.getSelection()) + 1);
			}else {
				map.put(node.getSelection(), 1);
			}
		}
		
		return map;
	}
	
	// print the number of nodes that selected each option
	public void printSelectionCounts() {
		
		Map<Integer, Integer> map = countNodesPerSelection();
		
		for(int selection: map.keySet()) {
			System.out.println("Selection: " + selection + " Count: " + map.get(selection));
		}	
	}
	
	// Calculates the total benefit for each possible option. 
	// The total benefit is the number of neighbors choosing the
	// option multiplied by the benefit factor. If there is a tie, 
	// it randomly chooses on the top options. This is important
	// because simply choosing the lowest numbered option will 
	// impact the results. 
	private int getNewChoice(Map<Integer, Integer> neighsChoices) {
		
		// map of total benefit for each option
		Map<Integer, Double> benefitAmounts = new HashMap<Integer, Double>();
					
		double topBenefit = -1;
					
		// list of options with maximum benefit
		List<Integer> finalist = new ArrayList<Integer>();
		
		// find the options with the top benefit
		// and also make a list of the top ones
		// if there is a tie
		for(int option: neighsChoices.keySet()) {

			int selectedCount = neighsChoices.get(option);
						
			double benefitFactor = benefitFactors.get(option);
						
			double optionBenefit = (selectedCount + 0.0) * benefitFactor; //* benefitFactor; 
						
			benefitAmounts.put(option, optionBenefit);
						
			if(optionBenefit > topBenefit) {
				topBenefit = optionBenefit;
				finalist = new ArrayList<Integer>();
				finalist.add(option);
			}else if(optionBenefit == topBenefit) {
				finalist.add(option);
			}
		}
				
		// chose from the leading choices
		// or if there's only 1 top choice, choose it
		int newChoiceIndex = myRand.nextInt(finalist.size());
							
		int newChoice = finalist.get(newChoiceIndex);

		return newChoice;
		
	}
	
	// For all the nodes, count the neighbors selections and
	// determine what the node will select next depending on 
	// its neighbors and the benefits factors. Counts the total 
	// amount of neighbors who chose each option. Calls getNewChoice
	// to determine what the node will do next. Returns the map
	// of node ids and next generation selections as a hashmap. 
	private Map<Integer, Integer> getNextGenSelections() {
		
		// next gen selections
		Map<Integer, Integer> newSelections = new HashMap<Integer, Integer>();

		for(int id: graph.keySet()) {
			
			Node n = graph.get(id);
			
			// total counts of neighbors selections
			Map<Integer, Integer> neighsChoices = new HashMap<Integer, Integer>();
			
			// count the node's neighbors by their current choice
			for(int neigh: n.getConnections()) {
				
				int nSelection = graph.get(neigh).getSelection();
				
				if(neighsChoices.containsKey(nSelection)) {
					int newCount = neighsChoices.get(nSelection) + 1;
					neighsChoices.put(nSelection, newCount);
				}else {
					neighsChoices.put(nSelection, 1);
				}
			}
			
			// send the neighbors counts to getNewChoice
			// to determine what the node will do next. 
			int newChoice = getNewChoice(neighsChoices);
			
			// save next gen choice
			newSelections.put(id, newChoice);
		}
		
		return newSelections;
			
	}
	
	// For the state of the graph before and after a generation, 
	// measure the percentage change of each selection option and
	// print the results to the console
	private void providePercentageChange(int howManyGens, Map<Integer, Integer> beforeCounts, 
			Map<Integer, Integer> afterCounts) {
		
		System.out.println("\nChanges for generation " + (howManyGens));
		
		for(int i=0; i<optionCount; i++) {
			
			double change = (afterCounts.get(i) + 0.0)/beforeCounts.get(i);
			
			String changeRounded = String.format("%.2f", change * 100 - 100);
			
			System.out.println("Option " + i + ": " + changeRounded + " %");
		
			if(i == optionCount - 1) {
				System.out.println("");
			}
		}
	}

	// Return the message about at which generation the group 
	// all had chosen a specific option
	public String getNodeGroupMessage() {
		return nodeGroupMessage;
	}
	
	// Analyze the designated group of nodes and check
	// if they have all made the specified selection. If
	// so, save the information in the group message and
	// mark the process as complete. 
	private void checkDesignatedNodes(int howManyGens) {
		
		if(nodeGroup == null || printed) {
			return;
		}
		
		for(int c: nodeGroup) {
			if( graph.get(c-1).getSelection() != nodeGroupChoice ) {
				return;
			}
		}
		
		printed = true;
		
		nodeGroupMessage += "\nAfter " + howManyGens + " generations the\n"
				+ "designated group of nodes\n" 
				+ "have all selected option " + nodeGroupChoice + ".\n";
	}
	
	// After determing the state of the graph in the next generation, 
	// update each node, check the designated nodes for the specified selection,
	// and measure and print the percentage change of each selection
	private void updateNodesAndMeasureChange(Map<Integer, Integer> newSelections, int howManyGens) {
		
		Map<Integer, Integer> beforeCounts = countNodesPerSelection();
		
		// update nodes with next gen choice
		for(int id: newSelections.keySet()) {
			graph.get(id).setSelection(newSelections.get(id));
		}
		
		Map<Integer, Integer> afterCounts = countNodesPerSelection();
		
		checkDesignatedNodes(howManyGens);
		
		providePercentageChange(howManyGens, beforeCounts, afterCounts);			
	}
	
	// Execute a generation including finding the new state
	// of the board, checking the designated nodes, and calculating
	// the percentage changes.
	public void generation(int howManyGens) {
		
		// next gen selections
		Map<Integer, Integer> newSelections = getNextGenSelections();
			
		// update nodes and print percentage changes
		updateNodesAndMeasureChange(newSelections, howManyGens);

	}
	

	
	public HashMap<Integer, Node> exportGraph() {
		// TODO Auto-generated method stub
		return graph;
	}
	
} 
