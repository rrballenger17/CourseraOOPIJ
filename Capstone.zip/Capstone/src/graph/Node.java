package graph;

import java.util.HashSet;

// Store information for each person or node in the graph
// including his or her ID, selection, and connections
public class Node {
	
	// id, selection, and connections
	// private variable values and getters
	// and setters to access the variables
	
	private int id = -1;
	
	public int getId() {
		return id;
	}
	
	public void setId(int input) {
		id = input;
	}
	
	private int selection = -1;
	
	public int getSelection() {
		return selection;
	}
	
	public void setSelection(int input) {
		selection = input;
	}
	
	private HashSet<Integer> connections = new HashSet<Integer>();

	public HashSet<Integer> getConnections(){
		return connections;
	}
	
	public void setConnections(HashSet<Integer> connections) {
		this.connections = connections;
	}
	
	
}
