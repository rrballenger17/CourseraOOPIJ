package graph;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import util.GraphLoader;

// Run the network cascade model simulation. Request and save
// input parameters from the user. Run the model accordingly
// print the results and other information in the console. 
public class Tests {
	
	public static void main(String[] args) {
		
		System.out.println("Begin Simulation:");
		
		GraphHardProblem g = new GraphHardProblem();

		// load the data
		GraphLoader.loadGraph((Graph)g, "data/facebook_ucsd.txt");

		// get the random seed value from the user
		Scanner reader = new Scanner(System.in);  // Reading from System.in
		System.out.println("\nTo seed the random generator for a repeatable state, ");
		System.out.println("enter the seed integer. Otherwise, press enter:");
		
		String seedInput = reader.nextLine();
	
		// save the seed value if given
		try { 
	        int seedInputParsed = Integer.parseInt(seedInput);
	        g.setRandomSeed(seedInputParsed);
	    } catch(Exception e) {}
		
		
		System.out.println("Enter number of generations: ");
		int numberOfGenerations = reader.nextInt();

		System.out.println("\nEnter number of choices per node: ");
		int numberOfChoices = reader.nextInt();
	          
		System.out.println("\nDetermine when certain nodes make a selection (y or n): ");
		String measureNodes = reader.next();
	          
		// if checking certain nodes for a particular selection, 
		// get the node ids and the specific selection option from
		// the user
		if(measureNodes.equals("y") || measureNodes.equals("Y")) {
			
			// Get and parse the node IDs from the user
			List<Integer> idsToCheck = new ArrayList<Integer>();
			System.out.println("\nEnter the node IDs separated by a space: ");
			reader.nextLine();
			String nodeIds = reader.nextLine();
			
			String[] nodeIdList = nodeIds.split(" ");
    	  	
			for(String nodeId: nodeIdList) {
				idsToCheck.add(Integer.parseInt(nodeId));	
			}
			
			// Get the selection option for the group nodes
			System.out.println("\nEnter the selection for the designated nodes: ");
			int idsToCheckSelection = reader.nextInt();
	        	  	
			// Save the node IDs and the selection option in 
			// the graph class and initialize the process of 
			// monitoring the nodes for the event that they all
			// have chosen the option
	  	    g.specificNodes(idsToCheck, idsToCheckSelection);
		}
	        	  
		// randomly assign selections. Psuedo random if the seed is set
		g.randomlyAssignSelection(numberOfChoices);
	          
		
		System.out.println("\nInitial selections counts:");
		g.printSelectionCounts();
	          
		// Execute the number of generations that was given by the user
		int count = 0;	          
		while(count++ < numberOfGenerations) {
			g.generation(count);
		}
	          
		// Print the final stats about the nodes and the message
		// about when the designated nodes chose the given option
		System.out.println("Final Selection Counts");
		g.printSelectionCounts();
		
		System.out.println(g.getNodeGroupMessage());
	           
	}
	
	

}
